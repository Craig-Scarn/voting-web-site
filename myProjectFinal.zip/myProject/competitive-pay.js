//It looks like planck.js is not working properly with p5.js but I decided to leave it in the project
//because there is some good coding in there (I spent a lot of time parsing data where salaries are
//passed to remove white space and commas)

function CompetitivePay() {
    var count = 0;
    // Name for the visualisation to appear in the menu bar.
    this.name = 'Competitive pay';
  
    // Each visualisation must have a unique ID with no special
    // characters.
    this.id = 'competitive-pay';
  
    // Property to represent whether data has been loaded.
    this.loaded = false;
    this.jobTitles;
    this.titlePay;
    this.maxPay;
    this.minPay;
    this.avgPay;
    
    //Function that structurs data into a format needed for visualization 
    this.addJobTitles = function() {
        var jobTitles = this.data.getColumn('job_title');
        var pay = this.data.getColumn('ctc'); 
        var uniqueJobs = { title: {} };
      
        for (var i = 0; i < jobTitles.length; i++) {
          var jobtile = jobTitles[i];
          
          if (!uniqueJobs.title[jobtile]) {
            console.log(uniqueJobs.title[jobtile]);
            uniqueJobs.title[jobtile] = {pay: [],}        
          }
          if (!uniqueJobs.title[jobtile].pay.includes(jobTitles[i])) {
            uniqueJobs.title[jobtile].pay.push(pay[i]);
          }
        }
        return uniqueJobs;
    }

    // Preload the data. This function is called automatically by the
    // gallery when a visualisation is added.
    this.preload = function() {
      var self = this;
      this.data = loadTable(
        './data/jobs/job.csv', 'csv', 'header',
        // Callback function to set the value
        // this.loaded to true.
        function(table) {
          self.loaded = true;
        });
    };
    var size = 10;
    this.setup = function() {
      if (!this.loaded) {
        console.log('Data not yet loaded');
        return;

      }

      this.layout = {
        // Margin positions around the plot. Left and bottom margins are
        // bigger so there is space for axis and tick labels on the canvas.
        leftMargin: 130,
        rightMargin: width - 300,
        midMargin: (width -300)/2 + 130/2 ,
        midFirstContainter: (width -300)/4 + 130/4,
        midSecondContainter: (width -300)/4*3 + 130/4*3,
        topMargin: 40,
        bottomMargin: height -80,
        pad: 5,
      };
    //Create a world for planck
    b2newWorld(30, b2V(0, 0.5));
    //create a body so the objects do not go off screen and stay in the containers 
    var f = new b2Body("edge", false, b2V(0, 0), [
        b2V(this.layout.leftMargin,this.layout.topMargin),
        b2V(this.layout.leftMargin,this.layout.bottomMargin),
        b2V(this.layout.midMargin,this.layout.bottomMargin),
        b2V(this.layout.midMargin, this.layout.topMargin)
    ], );
    var g = new b2Body("edge", false, b2V(0, 0), [
        b2V(this.layout.midMargin,this.layout.topMargin),
        b2V(this.layout.midMargin,this.layout.bottomMargin),
        b2V(this.layout.rightMargin,this.layout.bottomMargin),
        b2V(this.layout.rightMargin, this.layout.topMargin),
        b2V(this.layout.leftMargin, this.layout.topMargin)
    ]);

      this.jobTitles = this.addJobTitles();      
      this.titlePay = this.parseData();
      this.maxPay = this.getMaxPay(this.titlePay);
      this.minPay = this.getMinPay(this.titlePay);
      this.avgPay = this.getAvgPay(this.titlePay);

      var maxPaySize = map(this.maxPay[1], 0, this.maxPay[1], 0, 200);
      var minMaxPaySize = map(this.minPay[1], 0, this.maxPay[1], 0, 200);
      var avgMaxPaySize = map(this.avgPay[1], 0, this.maxPay[1], 0, 200);
      this.drawCircle(maxPaySize, this.layout.midFirstContainter - 50, 100);
      this.titlePay
      this.drawCircle(avgMaxPaySize, this.layout.midFirstContainter, 100);


      for(var i = 0; i < 100; i++){
        var size;
        size = map(this.titlePay[i].averagePay, 0, this.maxPay[1], 0, 200);
        this.drawCircle(size, this.layout.midSecondContainter + i * 0.1, 100);
      }
    };
    //Get the higest paid job for comparison 
    this.getMaxPay = function(array){
        var data = array;
        var maxPay = 0;
        var title;
        for(var i = 0; i < data.length; i++){
            if(data[i].averagePay > maxPay){
                maxPay = data[i].averagePay;
                title = data[i].title;
            }
        }
        return [title, maxPay];
    }
    //Get the lowest paid job for comparison 
    this.getMinPay = function(array){
        var data = array;
        var minPay = 99999999999999;
        var title;
        for(var i = 0; i < data.length; i++){
            if(data[i].averagePay < minPay){
                minPay = data[i].averagePay;
                title = data[i].title;
            }
        }
        return [title, minPay];

    }

    //Get the average paid job for comparison 
    this.getAvgPay = function(array){
        var data = array;
        var avgPay = 0;
        var title;
        for(var i = 0; i < data.length; i++){
            avgPay = avgPay + data[i].averagePay;
        }
        avgPay = avgPay/data.length
        return ["Average Pay", avgPay];

    }
    //parse data (remove white space and commas so it can be a single string)
    //https://stackoverflow.com/questions/14379274/how-to-iterate-over-a-javascript-object
    this.parseData = function(data){
        var data = data;
        var parsedData = [];
        
        for(let key in this.jobTitles.title){
            var averagePayPerTitle = 0;
            for(var i = 0; i < this.jobTitles.title[key].pay.length; i++){
                var removeUnwanted;
                //https://stackoverflow.com/questions/10610402/javascript-replace-all-commas-in-a-string
                removeUnwanted = this.jobTitles.title[key].pay[i].replace(/,/g, '');

                //https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Regular_Expressions
                var includeDigits = /\d+/g;
                removeUnwanted = removeUnwanted.match(includeDigits);
                if (removeUnwanted == null){
                    continue;
                }
                var averagePayPerCompany = 0;
                for(var j = 0; j < removeUnwanted.length; j++){
                    averagePayPerCompany += Number(removeUnwanted[j])
                }
                averagePayPerCompany = averagePayPerCompany/removeUnwanted.length;  
            }
            averagePayPerTitle = averagePayPerTitle + averagePayPerCompany;
            parsedData.push({'title': key,'averagePay':averagePayPerTitle});
        }
        return parsedData;
    }
    
    //Create an object that draws circles
    this.drawCircle = function(size, x, y){
        b = new b2Body(
            "circle",
            true,
            b2V(x, y),
            b2V(size, size),
             {filterCategoryBits: 4,
                 filterMaskBits: 4 + 1}
            );
        
    }

  
    this.draw = function() {
      if (!this.loaded) {
        console.log('Data not yet loaded');
        return;
      }
      fill('black');
      text('Max vs Min vs Avg pay jobs:',  this.layout.leftMargin + 10, this.layout.topMargin + 20);
      text(this.maxPay[0] + " " + this.maxPay[1] + " rupees",  this.layout.leftMargin + 10, this.layout.topMargin + 30);
      text(this.minPay[0] + " " + this.minPay[1] + " rupees",  this.layout.leftMargin + 10, this.layout.topMargin + 40);
      text('All jobs average pay scale',  this.layout.midMargin + 10, this.layout.topMargin + 20);
      fill('green');
      //draw and update objects
      b2Update();
      b2Draw(true);
    };
  }
  