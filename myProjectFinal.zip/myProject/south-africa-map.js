//This is a constructor fuction used to display a map and bar graph for south african elections
//Data will be sent to this constructor function to dispaly statistics


function SouthAfricaMap() {
    this.buttons = [];

    this.preload = function () {
        //use to easily move the map arround
        const moveDown = 15;
        const moveRight = 190;

        //The buttons need to be statically created in an object as the provinces are ar static positions
        //Had to cut a the map appart image from https://www.linx.co.za/samap.html
        //load imaged for each button
        this.buttons = [
            { name: 'Eastern Cape', button: new Clickable(), image: loadImage('./assets/images/EasternCape.png'),
            x: width/100*40+moveRight, y: height/100*63+moveDown},
            { name: 'Limpopo', button: new Clickable(), image: loadImage('./assets/images/Limpopo.png'),
            x: width/100*54+moveRight, y: height/100*-1+moveDown},
            { name: 'Freestate', button: new Clickable(), image: loadImage('./assets/images/Freestate.png'),
            x: width/100*45+moveRight, y: height/100*35+moveDown },
            { name: 'Gauteng', button: new Clickable(), image: loadImage('./assets/images/Gauteng.png'),
            x: width/100*54+moveRight, y: height/100*21+moveDown },
            { name: 'KZN', button: new Clickable(), image: loadImage('./assets/images/KZN.png'),
            x: width/100*61+moveRight, y: height/100*38+moveDown},
            { name: 'Mpumalanga', button: new Clickable(), image: loadImage('./assets/images/Mpumalanga.png'),
            x: width/100*60+moveRight, y: height/100*15+moveDown},
            { name: 'North West', button: new Clickable(), image: loadImage('./assets/images/NortWest.png'),
            x: width/100*38+moveRight, y: height/100*18+moveDown},
            { name: 'Northen Cape', button: new Clickable(), image: loadImage('./assets/images/NorthenCape.png'),
            x: width/100*16.5+moveRight, y: height/100*37+moveDown},
            { name: 'Western Cape', button: new Clickable(), image: loadImage('./assets/images/WesternCape.png'),
            x: width/100*20+moveRight, y: height/100*70+moveDown},
        ];

        //Change button elements (add image, name, scale etc.)
        for (let i = 0; i < this.buttons.length; i++) {
            const buttonData = this.buttons[i];
            const button = buttonData.button;

            button.locate(buttonData.x, buttonData.y);

            button.image = buttonData.image;
            button.text = buttonData.name;
            button.strokeWeight = 0;
            button.imageScale = 1.5;

            button.onOutside = function () {
                button.imageScale = 1.5;
            };
        }
    };

    //update buttons in setup 
    this.setup = function(first,second,third){
        var first = first;
        var second = second;
        var thrid = third;
        for (let i = 0; i < this.buttons.length; i++) {
            const buttonData = this.buttons[i];
            const button = buttonData.button;
            button.height = buttonData.image.height;
            button.width = buttonData.image.width;
            button.onHover = function () {
                button.imageScale = 1.9;
                drawBarGraph(first, second, thrid);
            };

        }

    }

    //
    this.draw = function (data) {
        background(255);
        textFont('poppins')
        var data = data;
        for (let i = 0; i < this.buttons.length; i++) {
            this.buttons[i].button.draw();
            const buttonData = this.buttons[i];
            const button = buttonData.button;
            //Dynamically changes data sent to buttons
            for (let i = 0; i < this.buttons.length; i++) {
                this.buttons[i].button.draw();
                const buttonData = this.buttons[i];
                const button = buttonData.button;

                if (buttonData.name == 'Eastern Cape') {
                    button.onHover = function () {
                        button.imageScale = 1.9;
                        drawBarGraph(Number(data.EC[0].percent), Number(data.EC[1].percent), Number(data.EC[2]?.percent ?? 0),
                        data.EC[0].party,data.EC[1].party,data.EC[2]?.party?? "None");
                    };
                }
                else if (buttonData.name == 'Limpopo') {
                    button.onHover = function () {
                        button.imageScale = 1.9;
                        drawBarGraph(Number(data.NP[0].percent), Number(data.NP[1].percent), Number(data.NP[2]?.percent ?? 0),
                        data.NP[0].party,data.NP[1].party,data.NP[2]?.party?? "None");
                    };
                }
                else if (buttonData.name == 'Freestate') {
                    button.onHover = function () {
                        button.imageScale = 1.9;
                        drawBarGraph(Number(data.FS[0].percent), Number(data.FS[1].percent), Number(data.FS[2]?.percent ?? 0),
                        data.FS[0].party,data.FS[1].party,data.FS[2]?.party?? "None");
                    };
                }
                else if (buttonData.name == 'Gauteng') {
                    button.onHover = function () {
                        button.imageScale = 1.9;
                        drawBarGraph(Number(data.GT[0].percent), Number(data.GT[1].percent), Number(data.GT[2]?.percent ?? 0),
                        data.GT[0].party,data.GT[1].party,data.GT[2]?.party?? "None");
                    };
                }
                else if (buttonData.name == 'KZN') {
                    button.onHover = function () {
                        button.imageScale = 1.9;
                        drawBarGraph(Number(data.NL[0].percent), Number(data.NL[1].percent), Number(data.NL[2]?.percent ?? 0),
                        data.NL[0].party,data.NL[1].party,data.NL[2]?.party?? "None");
                    };
                }
                else if (buttonData.name == 'Mpumalanga') {
                    button.onHover = function () {
                        button.imageScale = 1.9;
                        //If data is missing due to only 2 competitors in the election of this province assign 'none' to party and '0' to percent of votes
                        //https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Nullish_coalescing?ref=botting.rockshttps://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Nullish_coalescing?ref=botting.rocks
                        drawBarGraph(Number(data.MP[0].percent), Number(data.MP[1].percent), Number(data.MP[2]?.percent ?? 0),
                        data.MP[0].party,data.MP[1].party,data.MP[2]?.party?? "None");
                    };
                }
                else if (buttonData.name == 'North West') {
                    button.onHover = function () {
                        button.imageScale = 1.9;
                        drawBarGraph(Number(data.NW[0].percent), Number(data.NW[1].percent), Number(data.NW[2]?.percent ?? 0),
                        data.NW[0].party,data.NW[1].party,data.NW[2]?.party?? "None");
                    };
                }
                else if (buttonData.name == 'Northen Cape') {
                    button.onHover = function () {
                        button.imageScale = 1.9;
                        drawBarGraph(Number(data.NC[0].percent), Number(data.NC[1].percent), Number(data.NC[2]?.percent ?? 0),
                        data.NC[0].party,data.NC[1].party,data.NC[2]?.party?? "None");
                    };
                }
                else if (buttonData.name == 'Western Cape') {
                    button.onHover = function () {
                        button.imageScale = 1.9;
                        var errorFix = data.WC[2]?.percent;
                        if(errorFix == null ){
                            (errorFix) = 0;
                        }
                        drawBarGraph(Number(data.WC[0].percent), Number(data.WC[1].percent), errorFix,
                        data.WC[0].party,data.WC[1].party,data.WC[2]?.party?? "None");


                    };
                }
            }
        }
        fill('black')
        textAlign(CENTER);
        textSize(38);
        text('South African Election results', width / 2, height / 9);
    };
    
    //Called but clickable onHover to display party information in text and a bar graph
    drawBarGraph = function (first, second, third, party1, party2, party3) {
        
        //used of text information
        var displayPartyNametextX = width / 100 * 28;
        var displayPartyNametextY = height / 100 * 20;
        var graphSize = {
            x: width / 100 * 5,
            y: height / 100 * 10,
            w: width / 100 * 20,
            h: height / 100 * 80
        }

        //Use map to convert percentage to bar size
        var bars = [
            map(first, 0, 100, graphSize.x, graphSize.h) - 51.2,
            map(second, 0, 100, graphSize.x, graphSize.h)- 51.2,
            map(third, 0, 100, graphSize.x, graphSize.h)- 51.2
        ]

        //use to calculate the remaining partes after the top 3 or 2
        bars.push(map(100 - first - second - third, 0, 100, graphSize.x, graphSize.h));
        
        var barWidth = graphSize.w / bars.length;
        var sizeOfText = 22;

        textFont('poppins')
        fill('lightgrey');
        noStroke();
        rect(graphSize.x, graphSize.y, graphSize.w, graphSize.h);
        fill('black');
        textAlign(CENTER);
        textSize(sizeOfText);
        text("Percentage of top 3 party votes", graphSize.x + graphSize.w / 2,
            graphSize.y + graphSize.h + sizeOfText + 10);
        
        text("100%", displayPartyNametextX - 125, displayPartyNametextY - 40);
        
        //Display text percentage and party names 
        textSize(12);
        textAlign(LEFT);
        text(party1 + ' ' + first + " %", displayPartyNametextX, displayPartyNametextY );
        text(party2 + ' ' + second+ " %", displayPartyNametextX, displayPartyNametextY + 20);
        text((party3) + ' ' + (third)+ " %", displayPartyNametextX, displayPartyNametextY + 40);
        text(("Other") + ' ' + round(100 - first - second - third)+ " %", displayPartyNametextX, displayPartyNametextY + 60);
        
        //colour code the bars 
        for (var i = 0; i < bars.length; i++) {
            switch(true){
                case (i == 0):
                    fill('green');
                    break;
                case (i == 1):
                    fill('blue');
                    break;
                case (i == 2):
                    fill('red');
                    break;
                default:
                    fill('brown')
                }
            rect(graphSize.x + i * barWidth, graphSize.y + graphSize.h - bars[i], barWidth, bars[i])
            rect(displayPartyNametextX -14 , displayPartyNametextY - 10 + i *20, 11, 11)

        }
    };
}