// Constructor function display stats and draw player

function FootballPlayerStats(data,player) {
    var returnButtonX = width/9;
    var returnButtonY = height/9
    var returnButtonHeight = 30;
    var returnButtonWidth = 100;
    var returnText = 'Return'
    var barGraphY = 220;
    var barGraphHeight = height - barGraphY;
    var barGraphX = 110;

    //Displays each players stats in a seperate screen on a bar graph
    this.draw = function(name,age,country,finishing,tackling,dribbling,pHeight,value,vision,crossing, ball_control) {
    
        var playerAttributes = [name,age,country,pHeight,value];
        var playerStats = [['Crossing', crossing],['Finishing',finishing],['Tackling', tackling],['Dribbling', dribbling],['Vision', vision],['Ball Control', ball_control],['Crossing', crossing]];        
        var barHeight = (height - barGraphY)/(playerStats.length)
        var barGraphBackground = {
            x: barGraphX,
            y: barGraphY - (barHeight/2),
            colour: 'light grey',
            h: height - barGraphY,
            w: width - barGraphX
        }
        //display the bar graph
        noStroke();
        fill('grey');
        textSize(30);
        text("Name: " + playerAttributes[0], width/2, height/10);
        textAlign(CENTER);
        textSize(16);
        rect(barGraphBackground.x, barGraphBackground.y, barGraphBackground.w, barGraphBackground.h);
        text("Age: " + playerAttributes[1], width/2, height/10 + 32);
        text("Country: " + playerAttributes[2], width/2, height/10 + 32 + 18);
        text("Height: " + playerAttributes[3], width/2, height/10 + 32 + 18 + 18);
        text("Value: " + playerAttributes[4], width/2, height/10 + 32 + 18 + 18 + 18);
        textAlign(LEFT);
        noStroke();
        //var barHeight = (height - barGraphY)/(playerStats.length)
        for(var i = 0; i < playerStats.length ; i++){
            var b = map(Number(playerStats[i][1]),0,100,0,width - barGraphX); 
            var coulorOption = Number(playerStats[i][1]);
            //https://stackoverflow.com/questions/5619832/switch-on-ranges-of-integers-in-javascript
            switch(true){
                case (coulorOption > 80):
                    fill("gold");
                    break;
                case (coulorOption > 70):
                    fill('green');
                    break;
                case (coulorOption > 60):
                    fill('yellow');
                    break;
                case (coulorOption > 50):
                    fill('orange');
                    break;
                default:
                    fill('red');
            }          

            textAlign(CENTER);            
            rect(barGraphX,barGraphY + (i) * barHeight - (barHeight/2), b, barHeight);            
            fill('black')
            text(playerStats[i][1], barGraphX + b/2, barGraphY + (i) * barHeight);
            textAlign(LEFT);
            text(playerStats[i][0], barGraphX, barGraphY + (i) * barHeight);

        }
        textAlign(CENTER)
        fill('red');
        rect(returnButtonX, returnButtonY, returnButtonWidth, returnButtonHeight);
        fill('white');
        text(returnText, returnButtonX + textWidth(returnText), returnButtonY + returnButtonHeight/2 + 4);
        return 0;
    }

    //If no player is loaded retrun to select screen
    this.checkPlayerIsLoaded = function(name){
        var name = name;
        if(name == undefined){
            return 0;
        }
        else{
            return 1;
        }
    }
    
    //if the retrun button is pressed return to the select screen
    this.mousePressed = function(mouseX, mouseY){
        if(mouseX > returnButtonY &&
            mouseX < returnButtonX + returnButtonWidth &&
            mouseY > returnButtonY &&
            mouseY < returnButtonY + returnButtonHeight){
                return 0;
            }
        else{
            return 1;
        }
    }
}
