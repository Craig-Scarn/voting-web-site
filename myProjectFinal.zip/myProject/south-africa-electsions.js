function SouthAfricaElections() {

    // Name for the visualisation to appear in the menu bar.
    this.name = 'South Africa: Elections Results';
    var selectYears;
    var provinceCat;
    var selectedDropDownOption;
    var provinceToYearCategoryProvintial;
    var provinceToYearCategoryNational;


    // Each visualisation must have a unique ID with no special
    // characters.
    this.id = 'south-africa-elections';

    // Property to represent whether data has been loaded.
    this.loaded = false;
    var southAfricaMap = new SouthAfricaMap();
    
    // Preload the data. This function is called automatically by the
    // gallery when a visualisation is added.
    this.preload = function() {
        var self = this;
        // data source http://electionresources.org/za/data/ 
        this.data = loadTable(
        './data/elections/Elections2009-2019Shortened.csv', 'csv', 'header',
        // Callback function to set the value
        // this.loaded to true.
        function(table) {
            self.loaded = true;
        });
        southAfricaMap.preload();   

    };

    //structurning data into useable data
    this.addYearCategory = function() {
        var yearCategory = this.data.getColumn('year'); 
        var uniqueYears = { yearTitle: {} };
        var returnYears = [];
        for (var i = 0; i < yearCategory.length; i++) {
            var year = yearCategory[i];        
            if (!uniqueYears.yearTitle[year]) {
                uniqueYears.yearTitle[year] = {pay: [],}
                returnYears.push({'year': year})
            }
        }
        return returnYears;
    }

    //Splitting data into years (2009,2014 and 2019)
    this.addProvinceCategory = function(selectYears) {
        var provinceCategory = this.data.getColumn('province');
        var uniqueProvinces = { provinceTitle: {} };
        var returnProvinces = [];
        for (var i = 0; i < provinceCategory.length; i++) {
            var province = provinceCategory[i];        
            if (!uniqueProvinces.provinceTitle[province]) {
                uniqueProvinces.provinceTitle[province] = {pay: [],}
                returnProvinces.push({'province': province})
                
            }
        }
        return returnProvinces;
    }

    //Divide each year votes into provinces
    this.addProvinceYearCategory = function(provinceCat, selectYears) {
        var provinceYearCat = {};
        var year = this.data.getColumn('year');
        var province = this.data.getColumn('province');
        var parties = this.data.getColumn('party');
        var percent = this.data.getColumn('percent');
        var nationalOrPovince = this.data.getColumn('nationalOrPovince');
        
        for (var i = 0; i < year.length; i++) {
            for (var j = 0; j < selectYears.length; j++) {
                if (year[i] == selectYears[j].year) {
                    var yearData = {
                        'province': province[i],
                        'party': parties[i],
                        'percent': percent[i],
                        'nationalOrPovince': nationalOrPovince[i]
                    };
    
                    if (!provinceYearCat[year[i]]) {
                        provinceYearCat[year[i]] = [];
                    }
    
                    provinceYearCat[year[i]].push(yearData);
                }
            }
        }
    
        return(provinceYearCat);
    }
    
    //finally create a year, provices and divide into national or provitional elections
    this.addProvinceToYearCategory = function(yearCategory, NP) {
        var uniqueProvincesToYear = {};

        //https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/hasOwnProperty
        for (var year in yearCategory) {
            if (yearCategory.hasOwnProperty(year)) {
                uniqueProvincesToYear[year] = {};
                
                for (var i = 0; i < yearCategory[year].length; i++) {
                    var province = yearCategory[year][i].province;
                    var party = yearCategory[year][i].party;
                    var percent = yearCategory[year][i].percent;
                    var nationalOrPovince = yearCategory[year][i].nationalOrPovince;

                    //the nationalOrPovince == NP divides into national or provintial votes
                    if (!uniqueProvincesToYear[year][province] && nationalOrPovince == NP) {
                        uniqueProvincesToYear[year][province] = [];
                    }
                    if(!uniqueProvincesToYear[year][province] ){
                        continue;
                    }
                    else{
                        if(nationalOrPovince == NP){
                            uniqueProvincesToYear[year][province].push({ party: party, percent: percent, nationalOrPovince: nationalOrPovince});
                        }
                    }
                }
            }
        }
    
        return uniqueProvincesToYear;
    }
    
    
    this.setup = function() {
        if (!this.loaded) {
        console.log('Data not yet loaded');
            return;
        }
        //structure data into usable data
        selectYears = this.addYearCategory();
        provinceCat = this.addProvinceCategory();
        selectedDropDownOption = this.addProvinceYearCategory(provinceCat,selectYears);
        //final data used for display on map
        //provintial voting data
        provinceToYearCategoryProvintial = this.addProvinceToYearCategory(selectedDropDownOption, "P");
        //national votind data
        provinceToYearCategoryNational = this.addProvinceToYearCategory(selectedDropDownOption, "N");
        //create drop down menues to divide years and provinces up
        this.select = createSelect();
        this.select.position(width/4*3,height/100*12);
        this.selectProvNat = createSelect();
        this.selectProvNat.position(width/4*3 - 100,height/100*12);
        for(var i= 0; i < selectYears.length; i ++){
            this.select.option(selectYears[i].year);
        }
        
        this.selectProvNat.option("National");
        this.selectProvNat.option("Provintial");
        southAfricaMap.setup(5,5,3);

    };

    //destroy drop down menus 
    this.destroy = function() {
        this.select.remove();
        this.selectProvNat.remove();
    };


    this.draw = function() {
        if (!this.loaded) {
        console.log('Data not yet loaded');
            return;
        }
        noStroke();
        var whichDataToUse;

        //varialbes for drop down menus 
        var dropDownYear = this.select.value();
        var dropDownProvNat = this.selectProvNat.value();
        //https://stackoverflow.com/questions/8698792/javascript-object-key-beginning-with-number-allowed
        
        //assign a data set to use depending on the drop down option selected
        if(dropDownYear == '2009'){
            if(dropDownProvNat == "Provintial"){
                whichDataToUse = provinceToYearCategoryProvintial['2009'];
            }
            else if(dropDownProvNat == "National"){
                whichDataToUse = provinceToYearCategoryNational['2009'];
            }            
        }
        else if(dropDownYear == '2019'){
            if(dropDownProvNat == "Provintial"){
                whichDataToUse = provinceToYearCategoryProvintial['2019'];
            }
            else if(dropDownProvNat == "National"){
                whichDataToUse = provinceToYearCategoryNational['2019'];
            }   
            
        }
        else if(dropDownYear == '2014'){
            if(dropDownProvNat == "Provintial"){
                whichDataToUse = provinceToYearCategoryProvintial['2014'];
            }
            else if(dropDownProvNat == "National"){
                whichDataToUse = provinceToYearCategoryNational['2014'];
            }   
            
        }

        //finally run draw map function with the selected structured data
        southAfricaMap.draw(whichDataToUse);        
    };


}
