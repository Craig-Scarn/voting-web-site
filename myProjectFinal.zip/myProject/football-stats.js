function FootballStats() {

  // Name for the visualisation to appear in the menu bar.
  this.name = 'Football Stats';

  // Each visualisation must have a unique ID with no special
  // characters.
  this.id = 'football-stats';

  //Player shirt
  var shirtIcon;
  var screenOptions = 0;
  this.visPlayer = [];
  this.players;
  var player_country;
  this.allSquads = [];
  this.teams = []; 
  var imageSize = [];
  var propt;
  var footballCoutry;
  var singlePlayerStats = {};
  var freedomFont;

  // Layout object to store all common plot layout parameters and
  // methods.
  this.layout = {
    // Margin positions around the plot. Left and bottom margins are
    // bigger so there is space for axis and tick labels on the canvas.
    leftMargin: 130,
    rightMargin: width - 400,
    topMargin: 40,
    bottomMargin: height -60,
    pad: 5,
    feildWidth: width/2 - 230,
    box18 : (width/2 - 230)/2,
    goalPosts: 20,
    effect3D: 0.5,

    plotWidth: function() {
      return this.rightMargin - this.leftMargin;
    },
    plotHeight: function() {
      return this.bottomMargin - this.topMargin;
    },

    // Boolean to enable/disable background grid.
    grid: true,

    // Number of axis tick labels to draw so that they are not drawn on
    // top of one another.
    numXTickLabels: 10,
    numYTickLabels: 8,
  };


  // Middle of the plot: for 50% line.
  this.midX = (this.layout.plotWidth() / 2) + this.layout.leftMargin;
  this.midY = (this.layout.plotHeight() / 2) + this.layout.topMargin;
  // Default visualisation colours.
  this.femaleColour = color(255, 0 ,0);
  this.maleColour = color(0, 255, 0);

  // Property to represent whether data has been loaded.
  this.loaded = false;

  // Preload the data. This function is called automatically by the
  // gallery when a visualisation is added.
  this.preload = function() {
    var self = this;
    this.data = loadTable(
      './data/footy/player_stats.csv', 'csv', 'header',
      // Callback function to set the value
      // this.loaded to true.
      function(table) {
        self.loaded = true;
      });
    shirtIcon = loadImage('./data/icon/shirt.png')
    imageSize = width/12;
    //freedomFont = loadFont('assets/Freedom.ttf')
    
  };

  this.setup = function() {
    // Font defaults.
    textSize(16);
    this.players = this.data.getColumn('player');
    this.country = this.data.getColumn('country');
    this.addSquadsPlayers();
    this.teams =  this.addCoutry();
    //create slider for 3D effect
    this.slider = createSlider(0.5,
      1,
      1,
      0.05);
    //create slider for the field to have a 3D effect
    this.slider.position(400, 10);
    //Create a drop down to select each country
    this.select = createSelect();
    this.select.position(width*0.70 ,10);

    //load all countries in the select dropdown
    for(var propt in this.teams.country){
      this.select.option(propt);
    }
    footballCoutry = this.teams.country[0];
    //textFont(freedomFont);
    textFont('poppins');

    //Fixed set players
    var playerCoOrd = [
    [this.midX - imageSize/2, this.layout.bottomMargin - this.layout.bottomMargin/9,1, imageSize],
    [this.midX - (this.layout.feildWidth*0.75) - imageSize/2, this.layout.bottomMargin*0.75 - imageSize/2,2, imageSize],
    [this.midX - this.layout.feildWidth*0.25 - imageSize/2, this.layout.bottomMargin*0.75- imageSize/2,3, imageSize],
    [this.midX + this.layout.feildWidth*0.75 - imageSize/2, this.layout.bottomMargin*0.75 - imageSize/2,4, imageSize],
    [this.midX + this.layout.feildWidth*0.25 - imageSize/2, this.layout.bottomMargin*0.75- imageSize/2,5, imageSize],
    [this.midX - this.layout.feildWidth*0.35 - imageSize/2, this.layout.bottomMargin*0.55 - imageSize/2,6, imageSize],
    [this.midX + this.layout.feildWidth*0.35 - imageSize/2, this.layout.bottomMargin*0.55 - imageSize/2,7, imageSize],
    [this.midX - this.layout.feildWidth*0.55 - imageSize/2, this.layout.bottomMargin*0.35 - imageSize/2,8, imageSize],
    [this.midX + this.layout.feildWidth*0.00 - imageSize/2, this.layout.bottomMargin*0.35 - imageSize/2,9, imageSize],
    [this.midX + this.layout.feildWidth*0.55 - imageSize/2, this.layout.bottomMargin*0.35 - imageSize/2,10, imageSize],
    [this.midX + this.layout.feildWidth*0.00 - imageSize/2, this.layout.bottomMargin*0.12 - imageSize/2,11, imageSize],
    ] 
    for (var i = 0; i < playerCoOrd.length; i++){
      this.visPlayer.push(playerCoOrd[i]);
    }
    //Player stats
    singlePlayerStats = {
      name: '',
      country: '',
      goals: '',
      tackles: '',
      age: '',
      dribbles: '',
      height: '',
      value: ''
    }

  };

  this.destroy = function() {
    this.slider.remove();
    this.select.remove();
  };

  //structure data with each player into country
  this.addCoutry = function() {
    var countries = this.data.getColumn('country');
    var players = this.data.getColumn('player'); 
    var uniqueCountries = { country: {} };  
    for (var i = 0; i < countries.length; i++) {
      var countryName = countries[i]; 
      if (!uniqueCountries.country[countryName]) {
        uniqueCountries.country[countryName] = {
          players: [],
        };
      }
      // https://www.freecodecamp.org/news/check-if-an-item-is-in-an-array-in-javascript-js-contains-with-array-includes/
      if (!uniqueCountries.country[countryName].players.includes(players[i])) {
        uniqueCountries.country[countryName].players.push(players[i]);
      }
    }
    return uniqueCountries;
  };


  //list players to coutry
  this.addSquadsPlayers = function(){
    for(var i = 0; i < this.players.length; i++){
      this.allSquads.push({
        name: this.players[i],
        country: this.country[i]
      })
    }
    
  }

  //scroll buttons used move player names on the right up and down
  var scrollButton ={
    b : 2,
    x : width - (400),
    y : 50,
    y2 : height -50,
    h: 30,
    movePlayerList: 0
  }

  //function used to draw the scroll buttons 
  this.scrollButton = function(){
    fill('black')
    beginShape();
    vertex(scrollButton.x,scrollButton.y);
    vertex(scrollButton.x + scrollButton.h*2,scrollButton.y);
    vertex(scrollButton.x + scrollButton.h,scrollButton.y - scrollButton.h);
    vertex(scrollButton.x,scrollButton.y);
    endShape()
    beginShape();
    vertex(scrollButton.x,scrollButton.y2);
    vertex(scrollButton.x + scrollButton.h *2,scrollButton.y2);
    vertex(scrollButton.x + scrollButton.h,scrollButton.y2 +scrollButton.h);
    vertex(scrollButton.x,scrollButton.y2);
    endShape()
  }

  //Function scroll buttons pressed the player names will move up and down
  this.checkScrollButtonPressed = function(mouseX, mouseY){
    if(dist(scrollButton.x + scrollButton.h, scrollButton.y - scrollButton.h/2, mouseX, mouseY) < 30 ){
      scrollButton.movePlayerList += 5;
    }
    else if(dist(scrollButton.x + scrollButton.h, scrollButton.y2 + scrollButton.h/2, mouseX, mouseY) < 30){
      scrollButton.movePlayerList += -5;
    }

  }

  this.draw = function() {
    if (!this.loaded) {
      console.log('Data not yet loaded');
      
      return;
    }
    //fix for changing between extentions else player screen will load with undefiend data
    if(!singlePlayerStats.name){
      screenOptions = 0;
    }
    //Load different screen depending on Screen options
    if(screenOptions == 0){
      //draw players, scroll button and players shirts
      this.drawField();
      this.drawPlays(this.data);
      this.scrollButton(mouseX,mouseY);
      //move player names up and down
      if(mouseIsPressed){
        this.checkScrollButtonPressed(mouseX,mouseY);
        this.checkMouseOnFied(mouseX, mouseY);
      }
    }

    //display player stats on second screen
    else if(screenOptions == 1){      
      var a; //age
      var c; //country
      var f; //finishing
      var t; //tackling
      var d; //dribling
      var h; //height
      var v; //value
      var vi; //vission
      var b; //ballcontroll

      screenOptions = this.playerStats.checkPlayerIsLoaded(singlePlayerStats.name)
      if(mouseIsPressed){
        screenOptions = this.playerStats.mousePressed(mouseX,mouseY);
      }
      //Load the selected user stats
      for(var i = 0; i < this.data.getColumn('age').length;i ++){
        if (this.players[i] == singlePlayerStats.name){
          a = this.data.getColumn('age')[i];
          c = this.data.getColumn('country')[i];
          f = this.data.getColumn('finishing')[i];
          t = this.data.getColumn('stand_tackle')[i];
          d = this.data.getColumn('dribbling')[i];
          h = this.data.getColumn('height')[i];
          v = this.data.getColumn('value')[i];
          vi = this.data.getColumn('vision')[i];
          cr = this.data.getColumn('crossing')[i];
          b = this.data.getColumn('ball_control')[i];
          //break if player is selected - this improves the applications performance by a huge amount
          break;
        }
      }
      //draw the players stats in a bar graph and some additional info like player value and name
      this.playerStats.draw(singlePlayerStats.name,a,c,f,t,d,h,v,vi,cr,b);
      
    }  
  };

  //this is a manually created field witch could be improved on but using translate function (this will 
  //make the math behind the 3D field it easier
  this.drawField = function() {
    stroke(0);
    strokeWeight(2);
    fill('green');
    //change 3D value
    this.layout.effect3D = this.slider.value();
    //Change this to private variables 
    beginShape();
    vertex(this.midX - this.layout.feildWidth*this.layout.effect3D, this.layout.topMargin);
    vertex(this.midX + this.layout.feildWidth*this.layout.effect3D, this.layout.topMargin);
    vertex(this.midX + this.layout.feildWidth, this.layout.bottomMargin);
    vertex(this.midX - this.layout.feildWidth, this.layout.bottomMargin);
    vertex(this.midX - this.layout.feildWidth*this.layout.effect3D, this.layout.topMargin);
    endShape();
    arc(this.midX, this.midY, (this.layout.feildWidth*2)*(this.layout.effect3D*0.25), 160*(this.layout.effect3D/4), 0, PI);
    arc(this.midX, this.midY, (this.layout.feildWidth*2)*(this.layout.effect3D*0.25), 160*(this.layout.effect3D/4), PI, TWO_PI);
    beginShape();
    //center field line
    vertex(this.midX - this.layout.feildWidth + (this.layout.feildWidth -this.layout.feildWidth*this.layout.effect3D)/2, this.midY);
    vertex(this.midX + this.layout.feildWidth -(this.layout.feildWidth -this.layout.feildWidth*this.layout.effect3D)/2 , this.midY);
    endShape();
    beginShape();
    vertex(this.midX - this.layout.feildWidth*this.layout.effect3D , this.midY);
    vertex(this.midX + this.layout.feildWidth*this.layout.effect3D , this.midY);
    beginShape();
    //Draw far yard boxes
    vertex(this.midX -(this.layout.box18*this.layout.effect3D) -((this.layout.box18 - this.layout.box18*this.layout.effect3D)/5), this.layout.topMargin + this.midY/3);
    vertex(this.midX + (this.layout.box18*this.layout.effect3D) +((this.layout.box18 - this.layout.box18*this.layout.effect3D)/5) , this.layout.topMargin + this.midY/3);
    vertex(this.midX + this.layout.box18 *this.layout.effect3D, this.layout.topMargin );
    vertex(this.midX + (this.layout.box18/2)*this.layout.effect3D , this.layout.topMargin );
    vertex(this.midX + this.layout.box18/2*this.layout.effect3D +((this.layout.box18 - this.layout.box18*this.layout.effect3D)/5)/4 , this.layout.topMargin+ this.midY/8 );
    vertex(this.midX - this.layout.box18/2*this.layout.effect3D -((this.layout.box18 - this.layout.box18*this.layout.effect3D)/5)/4 , this.layout.topMargin + this.midY/8 );
    vertex(this.midX - this.layout.box18/2*this.layout.effect3D , this.layout.topMargin );
    vertex(this.midX - this.layout.box18 *this.layout.effect3D, this.layout.topMargin );
    vertex(this.midX - (this.layout.box18*this.layout.effect3D) -((this.layout.box18 - this.layout.box18*this.layout.effect3D)/5), this.layout.topMargin + this.midY/3);
    endShape();
    beginShape();
    vertex(this.midX - this.layout.box18/4*this.layout.effect3D, this.layout.topMargin );
    vertex(this.midX - this.layout.box18/4*this.layout.effect3D, this.layout.topMargin - this.layout.goalPosts);
    vertex(this.midX + this.layout.box18/4*this.layout.effect3D , this.layout.topMargin -this.layout.goalPosts);
    vertex(this.midX + this.layout.box18/4*this.layout.effect3D , this.layout.topMargin );
    endShape();
    //Draw close yard boxes
    beginShape();
    vertex(this.midX + this.layout.box18-((this.layout.box18 - this.layout.box18*this.layout.effect3D)/5), this.layout.bottomMargin - this.midY/3);
    vertex(this.midX - this.layout.box18 +((this.layout.box18 - this.layout.box18*this.layout.effect3D)/5), this.layout.bottomMargin - this.midY/3);
    vertex(this.midX - this.layout.box18 , this.layout.bottomMargin );
    vertex(this.midX - this.layout.box18/2 , this.layout.bottomMargin );
    vertex(this.midX - this.layout.box18/2 +((this.layout.box18 - this.layout.box18*this.layout.effect3D)/5)/4 , this.layout.bottomMargin - this.midY/8 );
    vertex(this.midX + this.layout.box18/2 -((this.layout.box18 - this.layout.box18*this.layout.effect3D)/5)/4 , this.layout.bottomMargin - this.midY/8 );
    vertex(this.midX + this.layout.box18/2 , this.layout.bottomMargin );
    vertex(this.midX + this.layout.box18 , this.layout.bottomMargin );
    vertex(this.midX + this.layout.box18 - ((this.layout.box18 - this.layout.box18*this.layout.effect3D)/5), this.layout.bottomMargin - this.midY/3);
    endShape();
    beginShape();
    vertex(this.midX - this.layout.box18/4, this.layout.bottomMargin );
    vertex(this.midX - this.layout.box18/4, this.layout.bottomMargin + this.layout.goalPosts);
    vertex(this.midX + this.layout.box18/4 , this.layout.bottomMargin +this.layout.goalPosts);
    vertex(this.midX + this.layout.box18/4 , this.layout.bottomMargin );
    endShape();
  }

  this.drawPlays = function(data){
    footballCoutry = this.select.value()
    var team = this.teams.country[footballCoutry];
    //uncomment for full data
    for(var i =0; i< 30; i++){ //if there are 30 or more players in a single country display only the first 30
    //Uncomment if you want fill data - this is a very large data set
    //for(var i =0; i< team.players.length; i++){
      var fontSize = 16;
      textSize(fontSize);
      var b = 2;
      stroke(0);
      fill(255);
      textAlign(CENTER);
      //After the first 10 players are drawn to screen display platers in scroll bar
      if(i > 10){
        fill('red')
        rect(width - textWidth(team.players[i]) - width*0.15 - b,
        ((i-10) * 25) - fontSize + scrollButton.movePlayerList, textWidth(team.players[i]) + b*2 , 
        fontSize + (b*4) );
        fill('white');
        text(team.players[i], 
        width - textWidth(team.players[i])/2 - width*0.15,
        (i- 10) * 25+ scrollButton.movePlayerList);
        continue;
      }
      //first 10 players dispalyed with shirts
      else{
        fill('red');
        rect(this.visPlayer[i][0] - textWidth(team.players[i])/2 + imageSize/2 - b,
        this.visPlayer[i][1] + imageSize - (b*3) , 
        textWidth(team.players[i]) + (b*3), 
        fontSize + (b*4) );
        fill('white')
        text(team.players[i], this.visPlayer[i][0] + this.visPlayer[i][3]/2,
          this.visPlayer[i][1] + imageSize + imageSize/9);
        image(shirtIcon, this.visPlayer[i][0], this.visPlayer[i][1],  this.visPlayer[i][3],  this.visPlayer[i][3]);
        text(this.visPlayer[i][2], this.visPlayer[i][0] + this.visPlayer[i][3]/2,
        this.visPlayer[i][1] + imageSize/2 + 5);
      }
    }
  }
  //
  this.mapPercentToWidth = function(percent) {
    return map(percent,
               0,
               100,
               0,
               this.layout.plotWidth());
  };


  //return player that has been clicked on and 1 to change screenOption
  this.checkMouseOnFied = function(mouseX, mouseY){
    var b = 2;
    var team = this.teams.country[footballCoutry];
    var fontSize = 16
    textSize(fontSize);
    textAlign(CENTER);
    //for speed perposes:
    for(var i =0; i< 30; i++){
    //Uncomment if you want fill data  
    //for(var i =0; i< team.players.length; i++){
      if(i > 10){
        if(mouseX > (width - textWidth(team.players[i]) - width*0.15 - b) &&
        mouseY > (((i-10) * 25) - fontSize) + scrollButton.movePlayerList &&
        mouseX <((width - textWidth(team.players[i]) - width*0.15 - b) + (textWidth(team.players[i]) + b*2)) &&
        mouseY < ((((i-10) * 25) - fontSize))+(fontSize + (b*4)) + scrollButton.movePlayerList){
          singlePlayerStats.name = team.players[i];
          screenOptions = 1;
        }
      }
      else if (i <= 10){
        if(mouseX > this.visPlayer[i][0] + this.visPlayer[i][3]/2  - textWidth(team.players[i])/2&& 
        mouseX < this.visPlayer[i][0] + this.visPlayer[i][3]/2 + textWidth(team.players[i])/2 &&
        mouseY > this.visPlayer[i][1] + imageSize - fontSize/2 - imageSize&&
        mouseY < this.visPlayer[i][1] + imageSize + imageSize/9 + fontSize/2 + imageSize){
          singlePlayerStats.name = team.players[i];
          screenOptions = 1;
        }
      }
    }
  }

  // Create a new player stats object.;
  this.playerStats = new FootballPlayerStats(this.data, singlePlayerStats.name);
}
